# 1.0.15
Changed Harvest Roll Result appearance
# 1.0.14
Added spell school Biomancy
# 1.0.13
fixed packs in module.json
# 1.0.12
added packs file and a compendium holding the macro for harvesting<br>
added system info to module.json
# 1.0.11
adjusted styling of harvest message to include first name and image of who rolled the check
# 1.0.10
changed the harvest message to include who rolled the check
# 1.0.9
fixed typo in roll breakdown
# 1.0.8
added breakdown to rolls
# 1.0.7
fixed typo
# 1.0.6
removed unneeded console logs<br>
adjusted the breakdown display of dice rolled
# 1.0.5
added title to harvest check message
# 1.0.4
minor fixes
# 1.0.3
minor fixes
# 1.0.2
minor fixes
# 1.0.1
minor fixes
# 1.0.0
Initial release
