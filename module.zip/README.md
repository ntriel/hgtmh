# Heliana's Guide To Monster Hunting harvesting Module for FoundryVTT
This module adds the capability to request rolls for harvesting a creature.

# How to use
run the Harvest macro provided in the Heliana's Harvesting Macros compendium. Messages will open in chat for player's to harvest