export const constants = {
    MODULEID: "hgtmh",
    DEBUG: "[Harvest Tool] DEBUG: ",
    ERROR: "[Harvest Tool] ERROR: ",
    INFO: "[Harvest Tool] INFO: ",
    ABILITIES: {assessment: "int", carving: "dex"}
}
